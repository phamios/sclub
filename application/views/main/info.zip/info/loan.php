
<div class="row">
    <div class="col-md-1">

    </div>
    <div class="col-md-10" style="padding:10px;">
        <h2>Vay thế chấp</h2>
        <p>Bạn có một khoản tiền nhàn rỗi ? Bạn đang tìm cách sinh lời bằng việc kinh doanh hoặc đầu tư nhưng chưa biết hướng kinh doanh nào phù hợp?</p>

        <p>Hãy bắt tay hợp tác cùng SCLUB để tham gia vào thị trường tài chính cá nhân đầy tiềm năng với biên lợi nhuận cao.</p>

        <p>Bạn ký hợp đồng cộng tác viên với SCLUB và được cấp mã kinh doanh. Bạn chỉ cần chia sẻ thông tin SCLUB cho bạn bè để cùng sử dụng tiện tích tài chính cá nhân thông minh và hưởng hoa hồng cộng tác hấp dẫn mỗi cuối tháng.</p>

        <p>Là cộng tác viên của SCLUB, bạn cũng có thể trực tiếp thực hiện món giao dịch cầm đồ với khách hàng theo quy định về quản lý và mẫu biểu của SCLUB. Chúng tôi sẽ cung cấp thông tin tư vấn khoản vay và hỗ trợ bạn thực hiện giao dịch phù hợp nhất.</p>

        <p>Hãy nắm cơ hội và bắt đầu từ hôm nay !</p>



        <p>Liên hệ ngay chúng tôi để được tư vấn thêm:</p>

        <p>Công ty Cổ Phần Thương Mại & Đầu Tư Sclub</p>

        <p>234 Nguyễn Trãi, Quận Thanh Xuân, Hà Nội</p>

        <p>Email: contact@sclub.vn</p>

        <p>Hotline: 1900 0043</p>
    </div>
    <div class="col-md-1">

    </div>
</div>
